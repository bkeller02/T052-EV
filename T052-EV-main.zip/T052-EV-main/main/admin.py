from django.contrib import admin

from .models import ContactSupport

admin.site.register(ContactSupport)
